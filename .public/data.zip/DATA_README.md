# Data explained
post_data.csv - the webscraped content of the subdread DarkNetMarkets
post_data_unique.csv - the cleaned version of the webscraped content of the posts, removed duplicates
onion_links.txt - the list of onion links fount from post content
clean_links.txt - the cleaned version of the onion links, removed duplicates and sorted to only use V3 links
working_links.txt - sorted for only the responding clean_links
links_data.csv - the webscraped content of the onion links
