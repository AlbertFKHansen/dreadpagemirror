# Data explained
post_data_unique.csv - the cleaned version of the webscraped content of the posts, removed duplicates
links_data.csv - the webscraped content of the onion links
links_to_sites.csv - contains known links and aliases to specific sites
explainer.ipynb - the Explainer Notebook
